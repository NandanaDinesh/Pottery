from django.db import models
from payment.models import Payment
from user.models import UserRegistration
from product.models import Product
from order.models import  Order
# Create your models here.

class Invoice(models.Model):
    invoice_id = models.AutoField(primary_key=True)
    invoice_number = models.CharField(max_length=45)
    # payment_id = models.IntegerField()
    payment=models.ForeignKey(Payment,on_delete=models.CASCADE)
    # user_id = models.IntegerField()
    user=models.ForeignKey(UserRegistration,on_delete=models.CASCADE)
    # product_id = models.IntegerField(blank=True, null=True)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    # order_id = models.IntegerField(blank=True, null=True)
    order=models.ForeignKey(Order,on_delete=models.CASCADE)

    class Meta:
        managed = True
        db_table = 'invoice'


