from django.conf.urls import url
from invoice import views
urlpatterns=[
    url('viewinvoiceuser/(?P<id>\w+)',views.viewinvoiceuser),
    url('viewinvoiceadmin/(?P<id>\w+)',views.viewinvoiceadmin)

]