from django.shortcuts import render, get_object_or_404
from django.shortcuts import render
from .models import Invoice
from order.models import Order,OrderItem
from user.models import UserRegistration


def viewinvoiceuser(request, id):
    order = Order.objects.get(order_id=id)
    user_id = request.session.get("uid")
    user = UserRegistration.objects.get(user_id=user_id)

    try:
        inv = Invoice.objects.get(order=order)  # get invoice linked to this order
    except Invoice.DoesNotExist:
        inv = None  # handle gracefully if invoice not yet created

    context = {
        "order": order,
        "user": user,
        "invoice": inv
    }
    return render(request, "invoice/viewinvoiceuser.html", context)

from django.shortcuts import render

#
# def viewinvoiceadmin(request, id):
#     order = Order.objects.get(order_id=id)
#     try:
#         inv = Invoice.objects.get(order=order)  # get invoice linked to this order
#     except Invoice.DoesNotExist:
#         inv = None  # handle gracefully if invoice not yet created
#
#     context = {
#         "order": order,
#         "invoice": inv
#     }
#     return render(request, "invoice/viewinvoiceadmin.html", context)

from django.shortcuts import render, get_object_or_404
from .models import Order


def viewinvoiceadmin(request, id):
    # Fetch the order
    order = get_object_or_404(Order, order_id=id)
    invoice=Invoice.objects.get(order_id=id)

    # Fetch all items related to this order
    items = OrderItem.objects.filter(order=order).select_related('product')

    # Calculate grand total
    grand_total = sum(item.price * item.order_quantity for item in items)

    context = {
        'order': order,
        'items': items,
        'grand_total': grand_total,
        'inv':invoice
    }

    return render(request, "invoice/viewinvoiceadmin.html", context)






