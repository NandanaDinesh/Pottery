from django.db import models
from user.models import UserRegistration
from product.models import Product

# Create your models here.
class Rating(models.Model):
    rating_id = models.AutoField(primary_key=True)
    rating = models.IntegerField()
    # user_id = models.IntegerField()
    user=models.ForeignKey(UserRegistration,on_delete=models.CASCADE)
    # product_id = models.CharField(max_length=45)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'rating'

