from django.conf.urls import url
from rating import views
urlpatterns = [
    url('rating/(?P<idd>\w+)', views.rating),
    url('view/', views.viewrating),
    url('admin/', views.adminrating)

]