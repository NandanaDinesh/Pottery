from django.shortcuts import render
from rating.models import Rating
from user.models import UserRegistration
from product.models import Product
# Create your views here.
def rating(request,idd):
    product=Product.objects.get(product_id=idd)
    u_id=request.session.get('uid')
    user=UserRegistration.objects.get(user_id=u_id)
    if request.method == 'POST':
        obj=Rating()
        obj.rating=request.POST.get('rating')
        obj.user=user
        obj.product=product
        obj.save()

    return render(request, 'rating/rating.html',{"pro":product})
def viewrating(request):
    u_id=request.session.get('uid')
    obj = Rating.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'rating/viewrating.html', context)
def adminrating(request):
    obj = Rating.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'rating/adminview.html', context)
