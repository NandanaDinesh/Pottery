from django.shortcuts import render,redirect
from cart.models import Cart,CartItem
from order.models import Order
from user.models import UserRegistration
from django.http import HttpResponseRedirect

def cart(request):
    return render(request, 'cart/viewcart.html')

def cart_view(request):
    obj = Cart.objects.all()
    context = {
        'cart': obj
    }
    return render(request,'cart/view_cc.html',context)

from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from product.models import Product
from cart.models import Cart, CartItem
from django.contrib import messages

def view_cart(request):
    # Get current user ID from session
    u_id = request.session.get("uid")
    if not u_id:
        messages.error(request, "Please login to view your cart.")
        return redirect('/temp/home/')

    # Get user's cart(s)
    try:
        carts = Cart.objects.get(user_id=u_id)

        # Get all items in user's cart(s)
        items = CartItem.objects.filter(cart=carts).select_related('product')

        # Calculate total amounts if needed (optional)
        for item in items:
            if item.total_amount is None:
                item.total_amount = item.quantity * item.product.product_price

        context = {
            'cart': items,  # pass items as 'cart' for your template
            'car':carts,
        }
    except:
        context={

        }

    return render(request, 'cart/viewcart.html', context)


def buy(request,idd):
    u_id=request.session.get("uid")
    if request.method == "POST":
        obj=Cart.objects.get(cart_id=idd)
        quantity = int(request.POST.get('quantity') or 1)  # default 1 if missing
        total_amount = float(request.POST.get('total_amount', 0))  # accept decimals

        obj.quantity = quantity
        obj.total_amount = int(total_amount)  # force integer for DB
        obj.save()

        ob = Order()
        ob.cart_id = obj.cart_id
        ob.user_id = u_id
        ob.status='pending'
        ob.order_quantity = quantity
        ob.total_amount = int(total_amount)
        ob.save()
        return HttpResponseRedirect(f'/payment/payment/{idd}/')
    return render(request,"cart/viewcart.html")

def delete(request, idd):
    # Fetch the specific CartItem by its ID and delete it
    item = get_object_or_404(CartItem, cartitem_id=idd)
    item.delete()
    return redirect('/cart/asdf/')  # redirect back to cart view page


from django.http import JsonResponse


from django.http import JsonResponse
from .models import CartItem

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt


@csrf_exempt  # Or use @csrf_protect if you handle CSRF token properly
def update_cartitem_quantity(request, cartitem_id):
    if request.method == "POST":
        qty = int(request.POST.get("quantity", 1))
        cart_item = CartItem.objects.get(cartitem_id=cartitem_id)
        cart_item.quantity = qty
        cart_item.total_amount = qty * cart_item.product.product_price
        cart_item.save()

        # Calculate total for the cart
        cart_total = sum(item.total_amount for item in CartItem.objects.filter(cart=cart_item.cart))

        return JsonResponse({
            "success": True,
            "item_total": cart_item.total_amount,
            "cart_total": cart_total
        })
    return JsonResponse({"success": False})
