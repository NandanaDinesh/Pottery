from django.conf.urls import url
from cart import views
from django.urls import path

urlpatterns = [
    url('cart/', views.cart),
    url('view/',views.cart_view),
    url('asdf/',views.view_cart),
    url('delete/(?P<idd>\w+)',views.delete),
    url('buy/(?P<idd>\w+)',views.buy),
    path('cartitem/<int:cartitem_id>/update_quantity/', views.update_cartitem_quantity, name='update_cartitem_quantity'),

    ]
