from django.conf.urls import url
from product import views
urlpatterns = [
    url('product/', views.product),
    url('view/', views.viewproduct),
    url('admin/',views.adminview),
    url('public/',views.publicview),
    url('update/(?P<idd>\w+)',views.update),
    url('delete/(?P<idd>\w+)', views.delete),
    url('add_cart/(?P<idd>\w+)', views.add_cart),
    url('update_stock/(?P<idd>\w+)', views.update_stock),

]