from django.shortcuts import render
from product.models import Product
from category.models import Category
from subcategory.models import Subcategory
from cart.models import Cart
from user.models import UserRegistration
from django.db.models import Q
from django.core.files.storage import FileSystemStorage
def product(request):
    ob=Category.objects.all()
    oo=Subcategory.objects.all()
    c={
        'cat':ob,
        'sub':oo
    }
    if request.method=='POST':
        cat=request.POST.get("main_category")
        subc=request.POST.get("sub_category")
        obj=Product()
        obj.stock=0
        obj.product_name=request.POST.get('product_name')
        obj.product_price=request.POST.get('product_price')
        obj.product_description=request.POST.get('product_desc')

        # obj.product_image=request.POST.get('product_image')
        # if 'product_image' in request.FILES:
        myfile=request.FILES["product_image"]
        fs=FileSystemStorage()
        filename=fs.save(myfile.name,myfile)
        obj.product_image=myfile.name

        obj.category=Category.objects.get(category_id = cat )
        obj.subcategory=Subcategory.objects.get(subcategory_id = subc)
        obj.quanity=request.POST.get('product_qty')
        obj.stock += int(obj.quanity)
        # obj.subcategory_id=1
        obj.save()

    return render(request, 'product/product.html',c)


from django.shortcuts import render, redirect
from cart.models import Cart
from product.models import Product
from user.models import UserRegistration
from category.models import Category

from django.shortcuts import render, redirect
from django.utils import timezone
from product.models import Product, Category
from user.models import UserRegistration
from cart.models import Cart, CartItem


def viewproduct(request):
    # Base querysets
    all_products = Product.objects.all()
    all_categories = Category.objects.all()

    # Get POST filters if any
    query = request.POST.get('query', '')
    category_filter = request.POST.get('category', 'All Categories')
    sort_filter = request.POST.get('sort', 'Price: Low to High')

    # Filter products based on search
    products = all_products
    if query:
        try:
            price = int(query)
            products = products.filter(product_name__icontains=query) | products.filter(product_price=price)
        except ValueError:
            products = products.filter(product_name__icontains=query)

    # Filter by category
    if category_filter and category_filter != "All Categories":
        products = products.filter(category_id=category_filter)

    # Sorting
    if sort_filter:
        if sort_filter == "Price: Low to High":
            products = products.order_by('product_price')
        elif sort_filter == "Price: High to Low":
            products = products.order_by('-product_price')
        elif sort_filter == "Newest First":
            products = products.order_by('-id')

    # Handle Add to Cart
    if request.method == "POST" and request.POST.get('action') == "carts":
        u_id = request.session.get('uid')
        user = UserRegistration.objects.get(user_id=u_id)
        product_id = request.POST.get('product_id')
        product = Product.objects.get(product_id=product_id)

        # Get or create user's cart
        cart, created = Cart.objects.get_or_create(user=user, defaults={'created_at': timezone.now()})

        # Get or create cart item
        cart_item, created_item = CartItem.objects.get_or_create(
            cart=cart,
            product=product,
            defaults={'quantity': 1, 'total_amount': product.product_price}
        )

        if not created_item:
            cart_item.quantity += 1
            cart_item.total_amount = cart_item.quantity * product.product_price
            cart_item.save()

        # Optional: redirect to avoid resubmission
        return redirect('viewproduct')  # replace with your URL name if using Django path names

    context = {
        'py': products,
        'cat': all_categories,
        'selected_category': category_filter,
        'selected_sort': sort_filter,
        'search_query': query
    }

    return render(request, "product/viewproduct.html", context)


# publc
def publicview(request):
    query = request.POST.get('query')
    category_filter = request.POST.get('category')
    sort_filter = request.POST.get('sort')

    # Always load categories
    all_categories = Category.objects.all()

    obj = Product.objects.all()
    objcat = Product.objects.all()

    if request.method == "POST":
            # Apply search filter (search by name or description instead of price)
            if query:
                obj = obj.filter(product_price=query)

            # obj = obj.filter(Q(product_name__icontains=query) or Q(product_description__icontains=query))

            # Apply category filter
            if category_filter and category_filter != "All Categories":
                obj = obj.filter(category_id=category_filter)

            # Apply sorting
            if sort_filter:
                if sort_filter == "Price: Low to High":
                    obj = obj.order_by('product_price')
                elif sort_filter == "Price: High to Low":
                    obj = obj.order_by('-product_price')
                elif sort_filter == "Newest First":
                    obj = obj.order_by('-id')
            print(type(category_filter))
            context = {
                'cat': objcat,
                'py': obj,
                'all_categories': all_categories,
                'selected_category': category_filter,
                'selected_sort': sort_filter,
                'search_query': query
            }
            return render(request, "product/publicview.html", context)
    else:
            obj = Product.objects.all()
            context = {
                'cat': objcat,
                'py': obj,
                'selected_category': "All Categories",
                'selected_sort': "Price: Low to High"
            }
            return render(request, "product/publicview.html", context)



def adminview(request):
    query = request.POST.get('query')
    category_filter = request.POST.get('category')
    sort_filter = request.POST.get('sort')

    # Always load categories
    all_categories = Category.objects.all()

    obj = Product.objects.all()
    objcat = Product.objects.all()

    if request.method == "POST":
        # Apply search filter (search by name or description instead of price)
        if query:
            obj = obj.filter(product_price=query)

        # obj = obj.filter(Q(product_name__icontains=query) or Q(product_description__icontains=query))

        # Apply category filter
        if category_filter and category_filter != "All Categories":
            obj = obj.filter(category_id=category_filter)

        # Apply sorting
        if sort_filter:
            if sort_filter == "Price: Low to High":
                obj = obj.order_by('product_price')
            elif sort_filter == "Price: High to Low":
                obj = obj.order_by('-product_price')
            elif sort_filter == "Newest First":
                obj = obj.order_by('-id')
        print(type(category_filter))
        context = {
            'cat': objcat,
            'py':obj,
            'all_categories': all_categories,
            'selected_category': category_filter,
            'selected_sort': sort_filter,
            'search_query': query
        }
        return render(request, "product/adminview.html", context)
    else:
        obj = Product.objects.all()
        context = {
            'cat': objcat,
            'py': obj,
            'selected_category': "All Categories",
            'selected_sort': "Price: Low to High"
        }
        return render(request, "product/adminview.html", context)


from django.shortcuts import render, redirect, get_object_or_404
from .models import Product

def update_stock(request, idd):
    # Get the product object or return 404 if not found
    product = get_object_or_404(Product, pk=idd)

    if request.method == 'POST':
        # Get new stock value from form
        new_stock = request.POST.get('stock')
        if new_stock:
            try:
                product.stock = int(new_stock)  # Update stock
                product.save()
            except ValueError:
                # Optionally handle invalid input
                pass

    # Redirect back to the products page after updating
    return redirect('/product/admin/')

from django.http import HttpResponseRedirect
def delete(request,idd):
    obj=Product.objects.get(product_id=idd)
    obj.delete()
    return HttpResponseRedirect('/product/admin/')

def update(request,idd):
    obj=Product.objects.get(product_id=idd)
    context={
        'up':obj
    }
    if request.method == 'POST':
        obj = Product.objects.get(product_id=idd)
        obj.stock = 0
        obj.product_name = request.POST.get('product_name')
        obj.product_price = request.POST.get('product_price')
        obj.product_description = request.POST.get('product_desc')

        # obj.product_image=request.POST.get('product_image')
        # if 'product_image' in request.FILES:
        myfile = request.FILES["product_image"]
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.product_image = myfile.name

        obj.category_id = 1
        obj.quanity = request.POST.get('product_qty')
        obj.stock += int(obj.quanity)
        obj.subcategory_id = 1
        obj.save()


    return render(request, 'product/product.html',context)




from django.shortcuts import redirect, get_object_or_404
from django.utils import timezone
from django.shortcuts import redirect, get_object_or_404
from django.utils import timezone

def add_cart(request, idd):
    u_id = request.session.get("uid")
    user = UserRegistration.objects.get(user_id=u_id)
    product = Product.objects.get(product_id=idd)

    # Get or create the user's cart
    cart, created = Cart.objects.get_or_create(user=user, defaults={'created_at': timezone.now()})

    # Get or create the cart item
    cart_item, created = CartItem.objects.get_or_create(
        cart=cart,
        product=product,
        defaults={'quantity': 1, 'total_amount': product.product_price}
    )

    if not created:
        cart_item.quantity += 1
        cart_item.total_amount = cart_item.quantity * product.product_price
        cart_item.save()

    # Redirect back to the product page
    return redirect('/product/view/')
