from django.shortcuts import render, redirect
from django.contrib import messages
from subcategory.models import Subcategory
from django.db import IntegrityError

def subcategory(request):
    if request.method == 'POST':
        subcategory_name = request.POST.get('subcategory_name').strip()
        try:
            obj = Subcategory()
            obj.category_id = 1  # or get this dynamically if needed
            obj.subcategory_name = subcategory_name
            obj.save()
            messages.success(request, f'Sub-category "{subcategory_name}" added successfully!')
        except IntegrityError:
            messages.error(request, f'Sub-category "{subcategory_name}" already exists!')
        return redirect('subcategory')  # redirect to same page to prevent resubmission

    return render(request, 'subcategory/subcategory.html')


def viewsubcategory(request):
    # fetch all subcategories
    subcategories = Subcategory.objects.select_related('category').all()
    context = {
        'subcategories': subcategories
    }
    return render(request, 'subcategory/viewsubcategory.html', context)