from django.urls import path
from subcategory import views

urlpatterns = [
    path('subcategory/', views.subcategory, name='subcategory'),
    path('view/', views.viewsubcategory, name='viewsubcategory'),
]
