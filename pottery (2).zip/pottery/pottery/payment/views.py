from django.shortcuts import render
from payment.models import Payment
from order.models import Order,OrderItem
from cart.models import Cart
from invoice.models import Invoice
# Create your views here.
import datetime
from django.http import HttpResponseRedirect
# def payment(request,idd):
#     c=Cart.objects.all()
#     oo=Order.objects.filter(order_id=idd)
#     c={
#         'i':oo,
#         'kk':c
#     }
#     if request.method=='POST':
#         obj=Order.objects.get(order_id=idd)
#         obj.status='paid'
#         obj.save()
#
#         ob=Payment()
#         ob.payment_method=request.POST.get('method')
#         if ob.payment_method=='card':
#             ob.cardholder_name=request.POST.get('name')
#             ob.card_number=request.POST.get('cardno')
#             ob.exp_date=request.POST.get('expiry')
#             ob.cvv=request.POST.get('cvv')
#         elif ob.payment_method=='upi':
#             ob.upi_id=request.POST.get('upid')
#         ob.date=datetime.datetime.now()
#         ob.order_id=obj.order_id
#         ob.status='paid'
#         ob.save()
#         return HttpResponseRedirect('/product/view/')
#     return render(request, 'payment/payment.html',c,oo)

def payment(request, idd):
    if request.method == 'POST':
        order=Order.objects.get(order_id=idd)
        # update order status
        order.status = 'paid'
        order.save()

        # create payment
        payment = Payment()
        payment.payment_method = request.POST.get('method')
        if payment.payment_method == 'card':
            payment.cardholder_name = request.POST.get('name')
            payment.card_number = request.POST.get('cardno')
            payment.exp_date = request.POST.get('expiry')
            payment.cvv = request.POST.get('cvv')
        elif payment.payment_method == 'upi':
            payment.upi_id = request.POST.get('upid')
        payment.date = datetime.datetime.now()
        payment.order = order   # ✅ correct FK assignment
        payment.status = 'paid'
        payment.save()

        # create invoice
        invoice = Invoice()
        invoice.order = order            # ✅ assign FK correctly

        invoice.payment = payment        # ✅ link payment
        invoice.user = order.user        # ✅ link user
        # for item in OrderItem.objects.filter(order=order):
        #     invoice.products.add(item)
            # auto-generate invoice number
        last_invoice = Invoice.objects.all().order_by('-invoice_id').first()
        if last_invoice:
            try:
                last_number = int(str(last_invoice.invoice_number).split('-')[-1])
            except ValueError:
                last_number = last_invoice.invoice_id  # fallback
            new_number = last_number + 1
        else:
            new_number = 1

        invoice.invoice_number = f"INV-{datetime.datetime.today().year}-{new_number:04d}"
        invoice.save()

        order_items = OrderItem.objects.filter(order=order)
        for item in order_items:
            product = item.product
            if product.stock is None:
                product.stock = 0
            product.stock -= item.order_quantity
            if product.stock < 0:
                product.stock = 0  # prevent negative stock
            product.save()


        return HttpResponseRedirect('/product/view/')

    return render(request, 'payment/payment.html', context)



def viewpayment(request):
    obj=Payment.objects.all()
    context={
        'py':obj
    }
    return render(request,'payment/viewpayment.html',context)

