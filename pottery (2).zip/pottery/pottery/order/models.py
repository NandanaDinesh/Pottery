from django.db import models
from user.models import UserRegistration
from cart.models import Cart
from product.models import Product

# Create your models here.



class Order(models.Model):
    order_id = models.AutoField(primary_key=True)
        # user_id = models.IntegerField()
    user=models.ForeignKey(UserRegistration,on_delete=models.CASCADE)
    total_amount = models.IntegerField(blank=True, null=True)
    status = models.CharField(max_length=45, blank=True, null=True)
    shipping = models.CharField(max_length=100, blank=True, null=True)
    phone = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'order'



class OrderItem(models.Model):
    order_item_id = models.AutoField(primary_key=True)
    # order_id = models.IntegerField()
    order=models.ForeignKey(Order,on_delete=models.CASCADE)
    # product_id = models.IntegerField()
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    order_quantity = models.IntegerField()
    price = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'order_item'
