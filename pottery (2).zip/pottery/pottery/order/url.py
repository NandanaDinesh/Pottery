from django.conf.urls import url
from order import views
from django.conf import settings
from django.urls import path

from django.conf.urls.static import static
urlpatterns = [
    url('order/(?P<idd>\w+)', views.order),
    url('vor/', views.vieworder),
    url('admin/',views.viewadmin),
    url('adress/(?P<idd>\w+)',views.shipping),
    url('orderitem/(?P<id>\w+)',views.orderitem),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)