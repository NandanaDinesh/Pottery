from django.shortcuts import render
from order.models import Order,OrderItem
from django.http import HttpResponseRedirect
from product.models import Product
from invoice.models import Invoice

from user.models import UserRegistration
# Create your views here.
import datetime
from cart.models import Cart,CartItem
def order(request, idd):
    u_id = request.session.get("uid")
    user = UserRegistration.objects.get(user_id=u_id)
    cart = Cart.objects.get(cart_id=idd)
    items = CartItem.objects.filter(cart=cart)

    if request.method == "POST":
        # Update each item's quantity from the POST data
        for item in items:
            qty_field = f"quantity_{item.cartitem_id}"  # use cartitem_id instead of id
            qty = request.POST.get(qty_field)
            if qty:
                item.quantity = int(qty)
                item.total_amount = item.quantity * item.product.product_price
                item.save()

        # Recalculate total amount after updating quantities
        total = sum(item.total_amount for item in items)

        # Create a new Order
        order_obj = Order()
        order_obj.user = user
        order_obj.total_amount = total
        order_obj.status = 'pending'  # keep pending until payment succeeds
        order_obj.save()

        # Create OrderItem objects for each CartItem
        for item in items:
            obj = OrderItem()
            obj.order = order_obj
            obj.product = item.product
            obj.order_quantity = item.quantity
            obj.price = item.total_amount
            obj.save()

        context = {
            "order": order_obj,
            "cart": cart,
            "items": items,
            "total": total,
            "order_id": order_obj.order_id,
        }

        return render(request, "payment/payment.html", context)
def order(request, idd):
    u_id = request.session.get("uid")
    user = UserRegistration.objects.get(user_id=u_id)
    cart = Cart.objects.get(cart_id=idd)
    items = CartItem.objects.filter(cart=cart)

    if request.method == "POST":
        # Update each item's quantity from the POST data
        for item in items:
            qty_field = f"quantity_{item.cartitem_id}"  # use cartitem_id instead of id
            qty = request.POST.get(qty_field)
            if qty:
                item.quantity = int(qty)
                item.total_amount = item.quantity * item.product.product_price
                item.save()

        # Recalculate total amount after updating quantities
        total = sum(item.total_amount for item in items)

        # Create a new Order
        order_obj = Order()
        order_obj.user = user
        order_obj.total_amount = total
        order_obj.status = 'pending'  # keep pending until payment succeeds
        order_obj.save()

        # Create OrderItem objects for each CartItem
        for item in items:
            obj = OrderItem()
            obj.order = order_obj
            obj.product = item.product
            obj.order_quantity = item.quantity
            obj.price = item.total_amount
            obj.save()

        context = {
            "order": order_obj,
            "cart": cart,
            "items": items,
            "total": total,
            "order_id": order_obj.order_id,
        }

        return render(request, "payment/payment.html", context)



def vieworder(request):
    ss = request.session.get('uid')
    orders = Order.objects.filter(user_id=ss)
    return render(request, 'order/vieworder.html', {"orders": orders})


def viewadmin(request):
    obj = Invoice.objects.all()

    context = {
        'py': obj
    }
    return render(request, 'order/viewadmin.html', context)

def shipping(request,idd):
    if request.method=='POST':
        obj=Order.objects.get(order_id=idd)
        obj.shipping=request.POST.get('shipping')
        obj.phone=request.POST.get('phone')
        obj.save()
        return HttpResponseRedirect(f'/payment/payment/{idd}/')
    return render(request,"order/shipping.html")
def orderitem(request,id):
    obj = Product.objects.get(product_id=id)

    return render(request,'order/orderitem.html',{"obj":obj})


# views.py

