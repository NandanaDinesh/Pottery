from django.shortcuts import render, redirect
from django.contrib import messages
from category.models import Category

# Create your views here.
def post_category(request):
    if request.method == 'POST':
        category_name = request.POST.get('category_name').strip()
        category_describe = request.POST.get('category_describe').strip()

        # ✅ Check if category already exists (case-insensitive)
        if Category.objects.filter(category_name__iexact=category_name).exists():
            messages.error(request, f'The category "{category_name}" already exists!')
        else:
            # ✅ Create new category only if it doesn't exist
            obj = Category()
            obj.category_name = category_name
            obj.category_describe = category_describe
            obj.product_id = 1
            obj.save()
            messages.success(request, f'Category "{category_name}" added successfully!')

        # Return to the same form page
        return redirect('post_category')

    return render(request, 'category/category.html')


def view_category(request):
    categories = Category.objects.all()  # get all categories
    context = {'categories': categories}
    return render(request, 'category/viewcategory.html', context)