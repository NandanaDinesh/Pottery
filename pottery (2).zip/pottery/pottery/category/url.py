from django.urls import path
from category import views

urlpatterns = [
    path('post_category/', views.post_category, name='post_category'),  # Add category page
    path('view_category/', views.view_category, name='view_category'),  # View categories page
]
