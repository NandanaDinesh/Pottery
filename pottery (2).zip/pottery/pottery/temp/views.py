from django.shortcuts import render


# Create your views here.
def home(request):


    return render(request, 'temp/home.html')


def adminhome(request):
    return render(request, 'temp/adminhome.html')

def userhome(request):
    return render(request, 'temp/userhome.html')

def publichome(request):
    return render(request, 'temp/publichome.html')