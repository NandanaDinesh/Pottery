from django.conf.urls import url
from temp import views
urlpatterns = [
    url('home/', views.home),
    url('admin/',views.adminhome),
    url('user/',views.userhome),
    url('public',views.publichome)
]