from django.shortcuts import render
from user.models import UserRegistration
from login.models import Login
from django.contrib import messages
import re

def user(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('mail')
        phone_number = request.POST.get('pnumber')
        username = request.POST.get('uname')

        # ✅ Email pattern check
        email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_regex, email):
            messages.error(request, "Invalid email format.")
            return render(request, 'user/user.html')

        # ✅ Email uniqueness
        if UserRegistration.objects.filter(email=email).exists():
            messages.error(request, "This email is already registered.")
            return render(request, 'user/user.html')

        # ✅ Username uniqueness
        if UserRegistration.objects.filter(username=username).exists():
            messages.error(request, "This username is already taken.")
            return render(request, 'user/user.html')

        # ✅ Phone number uniqueness
        if UserRegistration.objects.filter(phone_number=phone_number).exists():
            messages.error(request, "This phone number is already registered.")
            return render(request, 'user/user.html')

        # Save new user
        obj = UserRegistration(
            name=name,
            email=email,
            phone_number=phone_number,
            house_name=request.POST.get('hname'),
            place=request.POST.get('place'),
            district=request.POST.get('district'),
            pincode=request.POST.get('pcode'),
            state=request.POST.get('state'),
            username=username,
            password=request.POST.get('pass')
        )
        obj.save()

        # Save login info
        ob = Login(
            username=obj.username,
            password=obj.password,
            type="user",
            u_id=obj.user_id
        )
        ob.save()

        messages.success(request, "Registration successful! Please login.")
        return render(request, 'user/user.html')

    return render(request, 'user/user.html')
