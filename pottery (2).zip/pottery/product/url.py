from django.conf.urls import url
from product import views
urlpatterns = [
    url('product/', views.product),
    url('view/', views.viewproduct),
    url('admin/',views.adminview),
    url('public/',views.publicview)

]