from django.db import models
from category.models import Category
from subcategory.models import Subcategory

# Create your models here.

class Product(models.Model):
    product_id = models.AutoField(primary_key=True)
    product_name = models.CharField(max_length=45)
    product_price = models.IntegerField()
    product_description = models.CharField(max_length=45)
    # stock = models.IntegerField()
    product_image = models.CharField(max_length=1000)
    # category_id = models.IntegerField()
    category=models.ForeignKey(Category,on_delete=models.CASCADE)

    quanity = models.IntegerField()
    # subcategory_id = models.IntegerField()
    subcategory=models.ForeignKey(Subcategory,on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'product'


