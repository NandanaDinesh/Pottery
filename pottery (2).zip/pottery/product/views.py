from django.shortcuts import render
from product.models import Product
from category.models import Category
from cart.models import Cart
from django.db.models import Q
from django.core.files.storage import FileSystemStorage
def product(request):
    if request.method=='POST':
        obj=Product()
        obj.product_name=request.POST.get('product_name')
        obj.product_price=request.POST.get('product_price')
        obj.product_description=request.POST.get('product_desc')
        obj.stock=request.POST.get('product_stock')
        obj.product_image=request.POST.get('product_image')
        # if 'product_image' in request.FILES:
        #     myfile=request.FILES["product_image"]
        #     fs=FileSystemStorage()
        #     filename=fs.save(myfile.name,myfile)
        #     obj.product_image=myfile.name
        obj.category_id=1
        obj.quanity=request.POST.get('product_qty')
        obj.subcategory_id=1
        obj.save()

    return render(request, 'product/product.html')

def viewproduct(request):
    query = request.POST.get('query')
    category_filter = request.POST.get('category')
    sort_filter = request.POST.get('sort')
    all_categories = Category.objects.all()
    obj = Product.objects.all()
    objcat = Product.objects.all()

    if request.method == "POST":
        action=request.POST.get('action')
        if action == 'carts':
            ob=Cart()
            ob.product_id=request.POST.get('product_id')
            ob.user_id=1
            ob.save()

        if query:
            obj = obj.filter(product_price=query)
        if category_filter and category_filter != "All Categories":
            obj = obj.filter(category_id=category_filter)

        if sort_filter:
            if sort_filter == "Price: Low to High":
                obj = obj.order_by('product_price')
            elif sort_filter == "Price: High to Low":
                obj = obj.order_by('-product_price')
            elif sort_filter == "Newest First":
                obj = obj.order_by('-id')
        print(type(category_filter))
        context = {
            'cat': objcat,
            'py':obj,
            'all_categories': all_categories,
            'selected_category': category_filter,
            'selected_sort': sort_filter,
            'search_query': query
        }

        return render(request, "product/viewproduct.html", context)
    else:
        obj = Product.objects.all()
        context = {
            'cat': objcat,
            'py': obj,
            'selected_category': "All Categories",
            'selected_sort': "Price: Low to High"
        }
        return render(request, "product/viewproduct.html", context)


# publc
def publicview(request):
    query = request.POST.get('query')
    category_filter = request.POST.get('category')
    sort_filter = request.POST.get('sort')

    # Always load categories
    all_categories = Category.objects.all()

    obj = Product.objects.all()
    objcat = Product.objects.all()

    if request.method == "POST":
            # Apply search filter (search by name or description instead of price)
            if query:
                obj = obj.filter(product_price=query)

            # obj = obj.filter(Q(product_name__icontains=query) or Q(product_description__icontains=query))

            # Apply category filter
            if category_filter and category_filter != "All Categories":
                obj = obj.filter(category_id=category_filter)

            # Apply sorting
            if sort_filter:
                if sort_filter == "Price: Low to High":
                    obj = obj.order_by('product_price')
                elif sort_filter == "Price: High to Low":
                    obj = obj.order_by('-product_price')
                elif sort_filter == "Newest First":
                    obj = obj.order_by('-id')
            print(type(category_filter))
            context = {
                'cat': objcat,
                'py': obj,
                'all_categories': all_categories,
                'selected_category': category_filter,
                'selected_sort': sort_filter,
                'search_query': query
            }
            return render(request, "product/publicview.html", context)
    else:
            obj = Product.objects.all()
            context = {
                'cat': objcat,
                'py': obj,
                'selected_category': "All Categories",
                'selected_sort': "Price: Low to High"
            }
            return render(request, "product/publicview.html", context)



def adminview(request):
    query = request.POST.get('query')
    category_filter = request.POST.get('category')
    sort_filter = request.POST.get('sort')

    # Always load categories
    all_categories = Category.objects.all()

    obj = Product.objects.all()
    objcat = Product.objects.all()

    if request.method == "POST":
        # Apply search filter (search by name or description instead of price)
        if query:
            obj = obj.filter(product_price=query)

        # obj = obj.filter(Q(product_name__icontains=query) or Q(product_description__icontains=query))

        # Apply category filter
        if category_filter and category_filter != "All Categories":
            obj = obj.filter(category_id=category_filter)

        # Apply sorting
        if sort_filter:
            if sort_filter == "Price: Low to High":
                obj = obj.order_by('product_price')
            elif sort_filter == "Price: High to Low":
                obj = obj.order_by('-product_price')
            elif sort_filter == "Newest First":
                obj = obj.order_by('-id')
        print(type(category_filter))
        context = {
            'cat': objcat,
            'py':obj,
            'all_categories': all_categories,
            'selected_category': category_filter,
            'selected_sort': sort_filter,
            'search_query': query
        }
        return render(request, "product/adminview.html", context)
    else:
        obj = Product.objects.all()
        context = {
            'cat': objcat,
            'py': obj,
            'selected_category': "All Categories",
            'selected_sort': "Price: Low to High"
        }
        return render(request, "product/adminview.html", context)












