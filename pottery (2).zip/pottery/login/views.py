from django.shortcuts import render
from login.models import Login
from django.http import HttpResponseRedirect
# Create your views here.
def login(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        obj=Login.objects.filter(username=username,password=password)
        type=""
        for i in obj:
            type=i.type
            u_id=i.u_id
            if type=='admin':
                request.session['uid']=u_id
                return HttpResponseRedirect('/temp/admin/')
            elif type=='user':
                request.session['uid']=u_id
                return HttpResponseRedirect('/temp/user/')
    return render(request, 'login/login.html')
