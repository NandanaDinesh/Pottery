from django.shortcuts import render
from category.models import Category
# Create your views here.
def post_category(request):
    if request.method=='POST':
        obj=Category()
        obj.category_name=request.POST.get('category_name')
        obj.category_describe=request.POST.get('category_describe')
        obj.product_id=1
        obj.save()
    return render(request,'category/category.html')
def view_category(request):
    obj = Category.objects.all()
    context = {
        'py': obj
    }
    return render(request,'category/viewcategory.html',context)

