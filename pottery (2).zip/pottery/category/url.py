from django.conf.urls import url
from category import views

urlpatterns=[
 url('post_category/', views.post_category),
 url('view_category/',views.view_category)
]