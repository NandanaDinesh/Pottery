from django.shortcuts import render
from order.models import Order
# Create your views here.
import datetime
def order(request):
    if request.method=='POST':
        obj=Order()
        obj.user_id=1
        obj.product_id=1
        obj.total_amount=request.POST.get('tamount')
        obj.order_quantity=request.POST.get('quantity')
        obj.date=datetime.datetime.today()
        stock_id=1
        obj.save()

    return render(request, 'order/order.html')

def vieworder(request):
    obj = Order.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'order/vieworder.html', context)
def viewadmin(request):
    obj = Order.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'order/viewadmin.html', context)
