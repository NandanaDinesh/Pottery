from django.db import models
from user.models import UserRegistration
from product.models import Product

# Create your models here.

class Order(models.Model):
    order_id = models.AutoField(primary_key=True)
    # user_id = models.IntegerField()
    user=models.ForeignKey(UserRegistration,on_delete=models.CASCADE)

    # product_id = models.IntegerField()
    product=models.ForeignKey(Product,on_delete=models.CASCADE)

    total_amount = models.IntegerField()
    stock = models.IntegerField(blank=True, null=True)

    order_quantity = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'order'
