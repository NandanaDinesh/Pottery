from django.conf.urls import url
from invoice import views


urlpatterns =[
    url('invoice/', views.invoice),
    url('viewadmin/', views.view_invoiceadmin),
    url('viewuser/', views.view_invoiceuser)
]