from django.shortcuts import render
from invoice.models  import Invoice
# Create your views here.
def invoice(request):
    if request.method=='POST':
        obj=invoice()
        obj.invoice_number=request.POST.get('invoice')
        obj.payment_id=1
        obj.product_id=1
        obj.save()

    return render(request, 'invoice/invoice.html')
def view_invoiceadmin(request):
    obj = Invoice.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'invoice/viewinvoiceuser.html', context)

def view_invoiceuser(request):
    obj = Invoice.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'invoice/viewinvoiceuser.html', context)

