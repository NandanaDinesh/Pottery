from django.shortcuts import render
from payment.models import Payment
# Create your views here.
def payment(request):
    if request.method=='POST':
        obj=Payment()
        obj.order_id=1
        obj.total_amount=request.POST.get('')
        obj.payment_method=request.POST.get('')
        obj.save()
    return render(request, 'payment/payment.html')

def viewpayment(request):
    obj=Payment.objects.all()
    context={
        'py':obj
    }
    return render(request,'payment/viewpayment.html',context)

