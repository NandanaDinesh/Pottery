from django.db import models
from order.models import Order
# from invoice.models import Invoice

# Create your models here.
class Payment(models.Model):
    payment_id = models.AutoField(primary_key=True)
    # order_id = models.IntegerField()
    order=models.ForeignKey(Order,on_delete=models.CASCADE)

    # invoice_id = models.IntegerField()
    # invoice=models.ForeignKey(Invoice,on_delete=models.CASCADE)

    total_amount = models.IntegerField()
    payment_method = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'payment'

