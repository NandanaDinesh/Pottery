from django.shortcuts import render
from user.models import UserRegistration
from login.models import Login


# Create your views here.
def user(request):
    if request.method == 'POST':
        obj = UserRegistration()
        obj.name=request.POST.get('name')
        obj.email=request.POST.get('mail')
        obj.phone_number=request.POST.get('pnumber')
        obj.house_name=request.POST.get('hname')
        obj.place=request.POST.get('place')
        obj.district=request.POST.get('district')
        obj.pincode=request.POST.get('pcode')
        obj.state=request.POST.get('state')
        obj.username=request.POST.get('uname')
        obj.password=request.POST.get('pass')
        obj.save()


        ob=Login()
        ob.username=obj.username
        ob.password=obj.password
        ob.type="user"
        ob.u_id=obj.user_id
        ob.save()

    return render(request, 'user/user.html')
def viewuser(request):
    obj = UserRegistration.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'stock/viewstock.html', context)

