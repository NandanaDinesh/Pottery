from django.db import models

# Create your models here.
class UserRegistration(models.Model):
    user_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=45)
    email = models.CharField(max_length=45)
    phone_number = models.CharField(max_length=15)
    house_name = models.CharField(max_length=45)
    place = models.CharField(max_length=45)
    district = models.CharField(max_length=45)
    pincode = models.IntegerField()
    state = models.CharField(max_length=45)
    username = models.CharField(max_length=45)
    password = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'user_registration'
