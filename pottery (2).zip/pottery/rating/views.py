from django.shortcuts import render
from rating.models import Rating
# Create your views here.
def rating(request):
    if request.method == 'POST':
        obj=Rating()
        obj.rating=request.POST.get('rating')
        obj.user_id=1
        obj.product_id=1
        obj.save()

    return render(request, 'rating/rating.html')
def viewrating(request):
    obj = Rating.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'rating/viewrating.html', context)
