from django.conf.urls import url
from complaint import views

urlpatterns=[
url('postcomplaint/',views.complaint),
url('postreply/(?P<idd>\w+)',views.reply),
url('viewcomplaint/',views.viewcomplaint),
url('viewreply/',views.viewreply),
]