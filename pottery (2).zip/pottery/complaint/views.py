from django.shortcuts import render
from complaint.models import Complaint
# Create your views here.

def complaint(request):
    if request.method=='POST':
        obj=Complaint()
        obj.complaint=request.POST.get('complaint')
        obj.user_id=1
        obj.order_id=1
        obj.replay='pending'
        obj.save()
    return render(request,'complaint/complaint.html')

def reply(request,idd):
    if request.method=='POST':
        obj=Complaint.objects.get(complaint_id=idd)
        obj.replay=request.POST.get('reply')
        obj.save()
        return viewcomplaint(request)

    return render(request,'complaint/reply.html')
def viewcomplaint(request):
    obj = Complaint.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'complaint/viewcomplaint.html', context)
def viewreply(request):
    # ss=request.session['u_id']
    obj = Complaint.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'complaint/viewreply.html', context)
