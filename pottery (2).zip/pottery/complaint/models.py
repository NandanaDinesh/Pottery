from django.db import models
from  user.models import UserRegistration
from order.models import Order
# Create your models here.
class Complaint(models.Model):
    complaint_id = models.AutoField(primary_key=True)
    complaint = models.CharField(max_length=45)
    replay = models.CharField(max_length=45)
    # user_id = models.IntegerField()
    user = models.ForeignKey(UserRegistration, on_delete=models.CASCADE)
    # order_id = models.IntegerField()
    order=models.ForeignKey(Order,on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'complaint'
