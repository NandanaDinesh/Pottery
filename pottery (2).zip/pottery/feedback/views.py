from django.shortcuts import render
from feedback.models import Feedback
# Create your views here.

def feedback(request):
    if request.method=='POST':
        obj=Feedback()
        obj.feedback=request.POST.get('feedback')
        obj.user_id=1
        obj.product_id=1
        obj.save()

    return render(request,'feedback/feedback.html')
def view_feedbackadmin(request):
    obj = Feedback.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'feedback/viewfeedbackadmin.html', context)

def view_feedbackpublic(request):
    obj = Feedback.objects.all()
    context = {
        'yy': obj
    }
    return render(request, 'feedback/viewfeedbackpublic.html', context)

def view_feedbackuser(request):
    obj = Feedback.objects.all()
    context = {
        'uu': obj
    }
    return render(request, 'feedback/viewfeedbackuser.html', context)

