from django.db import models
from user.models import UserRegistration
from product.models import Product
# Create your models here.
class Feedback(models.Model):
    feedback_id = models.AutoField(primary_key=True)
    feedback = models.CharField(max_length=45)
    # user_id = models.IntegerField()
    user=models.ForeignKey(UserRegistration,on_delete=models.CASCADE)
    # product_id = models.IntegerField()
    product=models.ForeignKey(Product,on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'feedback'

