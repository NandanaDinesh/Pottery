from django.conf.urls import url
from feedback import views
urlpatterns=[
url('feedback/',views.feedback),
url('feedbackadmin/',views.view_feedbackadmin),
url('viewpublic/',views.view_feedbackpublic),
url('fuser/',views.view_feedbackuser)
]