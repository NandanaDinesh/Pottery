from django.shortcuts import render
from subcategory.models import Subcategory

# Create your views here.
def subcategory(request):
    if request.method == 'POST':
        obj = Subcategory()
        obj.category_id = 1
        obj.subcategory_name = request.POST.get('subcategory_name')
        obj.save()

    return render(request, 'subcategory/subcategory.html')
def viewsubcategory(request):
    obj = Subcategory.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'subcategory/viewsubcategory.html', context)

