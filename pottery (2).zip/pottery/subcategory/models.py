from django.db import models
from category.models import Category

# Create your models here.
class Subcategory(models.Model):
    subcategory_id = models.AutoField(primary_key=True)
    # category_id = models.CharField(max_length=45)
    category=models.ForeignKey(Category,on_delete=models.CASCADE)

    subcategory_name = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'subcategory'

