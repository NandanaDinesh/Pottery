from django.conf.urls import url
from subcategory import views
urlpatterns = [
    url('subcategory/', views.subcategory),
    url('view/', views.viewsubcategory)
    ]