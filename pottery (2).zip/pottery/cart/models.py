from django.db import models
from product.models import Product
from user.models import UserRegistration

# Create your models here.
# class Cart(models.Model):
    # cart_id = models.AutoField(primary_key=True)
    # # user_id = models.IntegerField()
    # user=models.ForeignKey(UserRegistration,on_delete=models.CASCADE)
    # # product_id = models.IntegerField()
    # product=models.ForeignKey(Product,on_delete=models.CASCADE)
    # quantity = models.IntegerField(blank=True, null=True)
    # stock = models.IntegerField(blank=True, null=True)
    # total_amount = models.IntegerField(blank=True, null=True)
    #
    # class Meta:
    #     managed = False
    #     db_table = 'cart'


class Cart(models.Model):
    cart_id = models.AutoField(primary_key=True)
    # user_id = models.IntegerField()
    user = models.ForeignKey(UserRegistration, on_delete=models.CASCADE)
    # product_id = models.IntegerField()
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    quantity = models.IntegerField(blank=True, null=True)
    stock = models.IntegerField(blank=True, null=True)
    total_amount = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'cart'
