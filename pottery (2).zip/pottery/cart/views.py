from django.shortcuts import render
from cart.models import Cart
from user.models import UserRegistration
from django.http import HttpResponseRedirect

def cart(request):
    return render(request, 'cart/viewcart.html')

def cart_view(request):
    obj = Cart.objects.all()
    context = {
        'cart': obj
    }
    return render(request,'cart/view_cc.html',context)

from django.http import HttpResponse
def view_cart(request):
    obj = Cart.objects.all()
    context = {
        'cart': obj
    }
    # return HttpResponse("hello")
    return render(request,'cart/viewcart.html',context)

def delete(request,idd):
    obj=UserRegistration.objects.get(user_id=idd)
    obj.delete()
    return HttpResponseRedirect('/cart/view_cart/')