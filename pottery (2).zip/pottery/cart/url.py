from django.conf.urls import url
from cart import views
urlpatterns = [
    url('cart/', views.cart),
    url('view/',views.cart_view),
    url('asdf/',views.view_cart),
    url('delete/(?P<idd>\w+)',views.delete)
]