from django.db import models
from product.models import Product
from category.models import Category
from subcategory.models import Subcategory

# Create your models here.
class Stock(models.Model):
    stockmanagement_id = models.AutoField(primary_key=True)
    stock = models.IntegerField()
    # product_id = models.IntegerField()
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    # category_id = models.IntegerField()
    category=models.ForeignKey(Category,on_delete=models.CASCADE)
    # subcategory_id = models.IntegerField()
    subcategory=models.ForeignKey(Subcategory,on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'stock'
