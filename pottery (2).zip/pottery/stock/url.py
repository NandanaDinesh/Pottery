from django.conf.urls import url
from stock import views
urlpatterns = [
    url('stock/', views.stock),
    url('viewstock/', views.viewstock)

]