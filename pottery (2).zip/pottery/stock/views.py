from django.shortcuts import render
from stock.models import Stock

# Create your views here.
def stock(request):
    if request.method == 'POST':
        obj=Stock()
        obj.stock=request
        obj.product_id=1
        obj.category_id=1
        obj.subcategory_id=1
        obj.stockmanagement_id=1
        obj.save()



    return render(request, 'stock/stock.html')
def viewstock(request):
    obj = Stock.objects.all()
    context = {
        'py': obj
    }
    return render(request, 'stock/viewstock.html.html', context)
